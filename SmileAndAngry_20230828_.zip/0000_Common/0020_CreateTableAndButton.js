'use strict'

class TableCreator {
    configAppli; // SmileAll同士、AngrySweeper同士で同じ、セルの数とか
    configTable; // FieldのTable同士、infoのTable同士で同じ、Fieldなのかinfoなのか
    configClickEvent; // Appli、Fieldで決まる。Infoは空
    configButton; // Infoのみ

    // プライベートフィールド
    #parent;
    #table;
    #tbody;
    #tr = [];
    #td = [];

    #eBtn = {};

    // プロパティ
    get vSize() { return this.configAppli.vSize; }
    get hSize() { return this.configAppli.hSize; }
    get cSize() { return this.vSize * this.hSize; }

    get parent() { return this.#parent; }
    get table() { return this.#table; }
    get tbody() { return this.#tbody; }
    get tr() { return this.#tr; }
    get td() { return this.#td; }

    get eBtn() { return this.#eBtn; }

    constructor(configAppli) {
        this.configAppli = configAppli;
    }

    createTable() {
        this.#parent = document.getElementById(this.configAppli.area);

        this.#table = document.createElement("table");
        this.#table.id = "fieldTable";
        this.#table.border = 1;
        this.#tbody = document.createElement("tbody");

        this.#tr = [];
        this.#td = [];
        this.#td = createBoxArray(this.vSize, this.hSize);

        for (let v = 0; v < this.vSize; v++) {
            this.#tr[v] = document.createElement("tr");
            for (let h = 0; h < this.hSize; h++) {
                this.#td[v][h] = document.createElement("td");
                this.#td[v][h].id = this.configTable.id(v, h);//`cell${c}`;
                this.#td[v][h].className = this.configTable.className(v, h);

                this.clickLeftEvent = this.configClickEvent.clickLeftEvent;
                this.clickRightEvent = this.configClickEvent.clickRightEvent;
                console.log(v,h);
                if (this.clickLeftEvent !== "undefined") this.#td[v][h].addEventListener("click", () => this.clickLeftEvent(v * this.hSize + h), false);
                if (this.clickRightEvent !== "undefined") this.#td[v][h].addEventListener("contextmenu", () => this.clickRightEvent(v * this.hSize + h), false);
                this.#td[v][h].oncontextmenu = "return false";
                this.#tr[v].appendChild(this.#td[v][h]);
            }
            this.#tbody.appendChild(this.#tr[v]);
        }
        this.#table.appendChild(this.#tbody);
        this.#parent.appendChild(this.#table);
    }

    createAllButton() {
        for (const key in this.configButton) {
            this.#eBtn[key] = this.#createButton(this.configButton[key]);
        }
    }

    #createButton(btn) {
        const el = document.createElement("button");
        el.innerText = btn.text;
        el.addEventListener(btn.event, btn.func, false);
        this.td[btn.vhOfInfo[0]][btn.vhOfInfo[1]].appendChild(el);
        return el;
    }
}
