'use strict'

class FieldBase extends TableCreator {
    constructor(configAppli, configClickEvent) {
        super(configAppli);

        this.configTable = {
            id: (v, h) => "cell" + padZeroToNum(v * this.hSize + h, 2),
            className: (v, h) => "cell",
        }

        this.configClickEvent = configClickEvent;

        this.createTable();
    }

    // 表示する
    show(status) {
        for (let i = 0; i < super.cSize; i++) {
            const v = posToV(i, super.hSize);
            const h = posToH(i, super.hSize);
            const stN = status[i];
            if (stN > statusNum.clicked) {
                this.td[v][h].style.backgroundColor = statusBGColor[stN];
                this.td[v][h].innerText = statusSymbol[stN];
            } else {
                this.td[v][h].style.backgroundColor = statusBGColor[statusNum.clicked];
                this.td[v][h].innerText = -stN;
            }
        }
    }
}

// // 1つのセルについて描画
// function showCell(el, stN) {
//     if (stN > statusNum.clicked) {
//         el.style.backgroundColor = statusBGColor[stN];
//         el.innerText = statusSymbol[stN];
//     } else {
//         el.style.backgroundColor = statusBGColor[statusNum.clicked];
//         el.innerText = -stN;
//     }
// }