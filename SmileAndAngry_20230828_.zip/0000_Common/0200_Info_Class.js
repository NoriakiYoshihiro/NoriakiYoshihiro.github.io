'use strict'

class InfoBase extends TableCreator {
    constructor(configAppli, configButton) {
        super(configAppli);

        this.configTable = {
            id: (v, h) => getInfoId(v, h),
            className: (v, h) => getInfoClass(h),
        }

        this.configClickEvent = {} // セルそのものはクリックにノーリアクション
        this.configButton=configButton;

        this.createTable();
        this.createAllButton();
    }

    giveClassName(v, h) {
        return getInfoClass(h);
    };
    // 定義マスト関数　TableCreatorでの作成テーブルの各tdのIdの命名ルール
    giveId(v, h) {
        return getInfoId(v, h);
    }
}

// HMTM areaInfoのclass,Idの命名
function getInfoClass(h) {
    return "info" + padZeroToNum(h, 2);
}
function getInfoId(v, h) {
    return "info" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[v] + padZeroToNum(h, 2);
}
