'use strict'

'use strict'
// ================================================================================
//    ! IMPORTANT ! 
//  Configuration for each of games
//  The configuration which is set here is used in this game control. 
// ================================================================================


// アプリごとに定義

const configAngrySweeper = {
    // Cell,Fieldのサイズ
    vSizeField: 12,
    hSizeField: 16,

    // Infoのサイズ
    vSizeInfo: 5,
    hSizeInfo: 2,

    // Fieldの配置Idタグ
    areaField: "areaFieldAngrySweeper",
    
    // Infoの配置Idタグ
    areaInfo: "areaInfoAngrySweeper",

    // Logの配置Idタグ
    areaLog: "areaLogAngrySweeper"
}

// ここまで



// 以下は自動設定される
const configCellAngrySweeper = {
    vSize: configAngrySweeper.vSizeField,
    hSize: configAngrySweeper.hSizeField
}

const configFieldAngrySweeper = {
    area: configAngrySweeper.areaField,
    vSize: configAngrySweeper.vSizeField,
    hSize: configAngrySweeper.hSizeField
}
const configInfoAngrySweeper = {
    area: configAngrySweeper.areaInfo,
    vSize: configAngrySweeper.vSizeInfo,
    hSize: configAngrySweeper.hSizeInfo
}
const configLogAngrySweeper = {
    area: configAngrySweeper.areaLog
}
