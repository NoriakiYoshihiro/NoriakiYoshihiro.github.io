'use strict'

// Field上での左クリックと右クリックのイベント
const configClickEventFieldAngrySweeper = {

    clickLeftEvent: (pos) => {
        // 必要ならここにコードを書く
        cellAngrySweeper.pushCell(pos);
        fieldAngrySweeper.show(cellAngrySweeper.statusForShow);
        infoAngrySweeper.show(cellAngrySweeper);
        cellAngrySweeper.isClearedAndDoEvent();
        // switchTextOfBtnRetry(cellAngrySweeper.isCleared());
    },

    clickRightEvent: (pos) => {
        logConsole.event("Clicked R.");
    }

}