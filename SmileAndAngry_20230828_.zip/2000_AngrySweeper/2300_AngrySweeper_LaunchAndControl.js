'use strict'

cellAngrySweeper.setInitialStatus();
cellAngrySweeper.try();

fieldAngrySweeper.show(cellAngrySweeper.statusForShow);
infoAngrySweeper.preshow();
infoAngrySweeper.show(cellAngrySweeper);
// switchTextOfBtnRetry(false);