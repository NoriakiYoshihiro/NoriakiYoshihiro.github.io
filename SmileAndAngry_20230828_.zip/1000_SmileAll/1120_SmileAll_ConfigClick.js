'use strict'

// Field上での左クリックと右クリックのイベント
const configClickEventFieldSmileAll = {

    clickLeftEvent: (pos) => {
        // 必要ならここにコードを書く
        cellSmileAll.pushCell(pos);
        fieldSmileAll.show(cellSmileAll.statusForShow);
        infoSmileAll.show(cellSmileAll);
        cellSmileAll.isClearedAndDoEvent();
        switchTextOfBtnRetry(cellSmileAll.isCleared());
    },

    clickRightEvent: (pos) => {
        logConsole.event("Clicked R.");
    }

}
