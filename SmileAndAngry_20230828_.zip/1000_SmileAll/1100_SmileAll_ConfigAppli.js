'use strict'
// ================================================================================
//    ! IMPORTANT ! 
//  Configuration for each of games
//  The configuration which is set here is used in this game control. 
// ================================================================================


// アプリごとに定義

const configSmileAll = {
    // Cell,Fieldのサイズ
    vSizeField: 5,
    hSizeField: 5,

    // Infoのサイズ
    vSizeInfo: 6,
    hSizeInfo: 2,

    // Fieldの配置Idタグ
    areaField: "areaFieldSmileAll",
    
    // Infoの配置Idタグ
    areaInfo: "areaInfoSmileAll",

    // Logの配置Idタグ
    areaLog: "areaLogSmileAll"
}

// ここまで



// 以下は自動設定される
const configCellSmileAll = {
    vSize: configSmileAll.vSizeField,
    hSize: configSmileAll.hSizeField
}

const configFieldSmileAll = {
    area: configSmileAll.areaField,
    vSize: configSmileAll.vSizeField,
    hSize: configSmileAll.hSizeField
}
const configInfoSmileAll = {
    area: configSmileAll.areaInfo,
    vSize: configSmileAll.vSizeInfo,
    hSize: configSmileAll.hSizeInfo
}
const configLogSmileAll = {
    area: configSmileAll.areaLog
}