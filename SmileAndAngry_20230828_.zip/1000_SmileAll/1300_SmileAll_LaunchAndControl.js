'use strict'

cellSmileAll.setInitialStatus();
cellSmileAll.try();

fieldSmileAll.show(cellSmileAll.statusForShow);
infoSmileAll.preshow();
infoSmileAll.show(cellSmileAll);
switchTextOfBtnRetry(false);