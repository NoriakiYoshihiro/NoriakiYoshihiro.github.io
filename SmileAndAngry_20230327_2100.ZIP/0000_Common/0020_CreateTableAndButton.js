'use strict'

class TableCreator {
    #parent;
    #table;
    #tbody;
    #tr = [];
    #td = [];

    #eBtn={};

    get parent() { return this.#parent; }
    get table() { return this.#table; }
    get tbody() { return this.#tbody; }
    get tr() { return this.#tr; }
    get td() { return this.#td; }

    get eBtn() { return this.#eBtn; }

    constructor() {}

    createTable(parentId, vSize, hSize) {// giveClassNameFunc, giveIdFunc) {
        this.#parent = document.getElementById(parentId);

        this.#table = document.createElement("table");
        this.#table.id = "fieldTable";
        this.#table.border=1;
        this.#tbody = document.createElement("tbody");

        this.#tr = [];
        this.#td = [];
        this.#td = createBoxArray(vSize, hSize);
        for (let v = 0; v < vSize; v++) {
            this.#tr[v] = document.createElement("tr");
            for (let h = 0; h < hSize; h++) {
                this.#td[v][h] = document.createElement("td");
                this.#td[v][h].className = this.configOfTable.className(v, h);
                this.#td[v][h].id = this.configOfTable.id(v, h);//`cell${c}`;
                this.#td[v][h].addEventListener("click", this.configOfTable.clickEvent(v, h), false);
                this.#tr[v].appendChild(this.#td[v][h]);
            }
            this.#tbody.appendChild(this.#tr[v]);
        }

        this.#table.appendChild(this.#tbody);
        this.#parent.appendChild(this.#table);
    }

    createAllButton(configButton) {
        for (const key in configButton) {
            this.#eBtn[key] = this.#createButton(configButton[key]);
        }
    }

    #createButton(configObj) {
        const el = document.createElement("button");
        el.innerText = configObj.text;
        el.addEventListener(configObj.event, configObj.func, false);
        this.td[configObj.vhOfInfo[0]][configObj.vhOfInfo[1]].appendChild(el);
        return el;
    }
}
