'use strict'

// 1つのセルについて描画
function showCell(el, stN) {
    if (stN > statusNum.clicked) {
        el.style.backgroundColor = statusBGColor[stN];
        el.innerText = statusSymbol[stN];
    } else {
        el.style.backgroundColor = statusBGColor[statusNum.clicked];
        el.innerText = -stN;
    }
}