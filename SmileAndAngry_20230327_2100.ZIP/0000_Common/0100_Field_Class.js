'use strict'

class FieldBase extends TableCreator {
    #vSize;
    #hSize;
    #cSize;

    // 定義マスト　TableCreatorでの作成テーブルの各tdのclassの命名ルール
    configOfTable = {
        className: (v, h) => "cell",
        id: (v, h) => "cell" + padZeroToNum(v * this.#hSize + h, 2),
        clickEvent: (v, h) => () => pushCellAndShow(v * this.#hSize + h)
        // 上記アローは以下と同じ
        // clickEvent: function (v,h) { return function () { pushCellAndShow(v * hSize + h);}; }
    }

    constructor(configClass) {
        super();
        this.#vSize = configClass.vSizeField;
        this.#hSize = configClass.hSizeField;
        this.#cSize = this.#vSize * this.#hSize;
        this.createTable(configClass.areaField, this.#vSize, this.#hSize);
    }

    show(status) {
        for (let i = 0; i < this.#cSize; i++) {
            const v = posToV(i,this.#hSize);
            const h = posToH(i,this.#hSize);
            const stN = status[i];
            if (stN > statusNum.clicked) {
                this.td[v][h].style.backgroundColor = statusBGColor[stN];
                this.td[v][h].innerText = statusSymbol[stN];
            } else {
                this.td[v][h].style.backgroundColor = statusBGColor[statusNum.clicked];
                this.td[v][h].innerText = -stN;
            }
        }
    }
}