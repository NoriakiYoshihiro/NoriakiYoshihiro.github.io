'use strict'

class InfoBase extends TableCreator {
    #vSize;
    #hSize;
    #cSize;

    // 定義マスト　TableCreatorでの作成テーブルの各tdのclassの命名ルール
    configOfTable = {
        className: function (v, h) { return getInfoClass(h); },
        id: function (v, h) { return getInfoId(v, h); },
        clickEvent: (v, h) => () => { } // 何もしない関数を値として返す
    }

    constructor(configClass, configButton) {
        super();
        this.#vSize = configClass.vSizeInfo;
        this.#hSize = configClass.hSizeInfo;
        this.#cSize = this.#vSize * this.#hSize;
        this.createTable(configClass.areaInfo, this.#vSize, this.#hSize);
        this.createAllButton(configButton);
    }

    giveClassName(v, h) {
        return getInfoClass(h);
    };
    // 定義マスト関数　TableCreatorでの作成テーブルの各tdのIdの命名ルール
    giveId(v, h) {
        return getInfoId(v, h);
    }


}


