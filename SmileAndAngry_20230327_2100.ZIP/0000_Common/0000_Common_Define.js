'use strict'

// Never delete following lines.
// 以下の行は消さないこと

const statusNum = { clicked: 0, nonClicked: 1, smile: 2, angry: 3, flag: 4, wall: 5 };
const statusArray = ["clicked", "nonClicked", "smile", "angry", "flag", "wall"];
const statusBGColor = ["lightgreen", "#BFBFBF", "lightgreen", "violet", "#BFBFBF", "gray"];
const statusSymbol = ["", "🌸", "😀", "😡", "🏴‍☠️", "🚧"];


function setDirect4(hSize) {
    return { upper:-hSize, left: -1, self: 0, right: +1, lower: +hSize, };
}

function setDirect8(hSize) {
    return {
        UpL: -hSize - 1, upper: -hSize, UpR: -hSize + 1,
        left: -1, self: 0, right: +1,
        LoL: +hSize - 1, lower: +hSize, LoR: +hSize + 1
    };
}


// その方向がフィールドの中かを返す関数を返す
function setIsFieldInside(vSize, hSize) {
    const direct=setDirect8(hSize);
    return (pos, dirN) => {
        if (dirN === direct.UpL && (pos < hSize || pos % hSize === 0)) return false;
        if (dirN === direct.upper && pos < hSize) return false;
        if (dirN === direct.UpR && (pos < hSize || pos % hSize === hSize - 1)) return false;

        if (dirN === direct.left && pos % hSize === 0) return false;
        if (dirN === direct.right && pos % hSize === hSize - 1) return false;

        if (dirN === direct.LoL && (pos >= hSize * (vSize - 1) || pos % hSize === 0)) return false;
        if (dirN === direct.lower && pos >= hSize * (vSize - 1)) return false;
        if (dirN === direct.LoR && (pos >= hSize * (vSize - 1) || pos % hSize === hSize - 1)) return false;
        return true;
    }
}