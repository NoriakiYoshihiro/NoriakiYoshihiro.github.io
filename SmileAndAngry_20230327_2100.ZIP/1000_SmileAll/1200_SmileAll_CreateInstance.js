'use strict'
// ================================================================================
//    ! IMPORTANT ! 
//  Common instance creation
//  Don't touch this page. 
// ================================================================================

const loggerSmileAll = new Logger(configSmileAll);

const cellSmileAll = new CellSmileAll(configSmileAll);

const fieldSmileAll = new Field(configSmileAll);

const infoSmileAll = new Info(configSmileAll, configButtonSmileAll);
