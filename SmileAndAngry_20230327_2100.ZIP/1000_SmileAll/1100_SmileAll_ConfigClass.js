'use strict'
// ================================================================================
//    ! IMPORTANT ! 
//  Configuration for each of games
//  The configuration which is set here is used in this game control. 
// ================================================================================


const configSmileAll = {
    areaField: "areaFieldSmileAll",
    vSizeField: 5,
    hSizeField: 5,

    areaInfo: "areaInfoSmileAll",
    vSizeInfo: 6,
    hSizeInfo: 2,

    areaLog: "areaLogSmileAll"
}
