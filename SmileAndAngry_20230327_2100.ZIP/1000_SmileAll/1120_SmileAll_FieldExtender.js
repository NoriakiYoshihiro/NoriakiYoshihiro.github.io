'use strict'
// ================================================================================
//    ! IMPORTANT ! 
//  Configuration for each of games
//  The configuration which is set here is used in this game control. 
// ================================================================================


// FieldBaseに個別追加する必要があるフィールド、プロパティ、メソッドがあればここに記述する
class Field extends FieldBase {
    // 必要ならここにコードを書く

}

// FieldのセルがpushされたときのeventListerが処理する内容を記述
function pushCellAndShow(c) {
    // 必要ならここにコードを書く
    cellSmileAll.pushCell(c);
    fieldSmileAll.show(cellSmileAll.statusForShow);
    infoSmileAll.show(cellSmileAll);
    cellSmileAll.isClearedAndDoEvent();
    switchTextOfBtnRetry(cellSmileAll.isCleared());
}
