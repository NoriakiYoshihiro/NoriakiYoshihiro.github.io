'use strict'

cell.setInitialStatus();
cell.try();

field.show(cell.statusForShow);
info.preshow();
info.show(cell);
switchTextOfBtnRetry(false);